import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

public class Task {
    
    Timer timer;
    
    public Task(int seconds){
        timer = new Timer();
        timer.schedule(new RemindTaskOne(), seconds*(1000/2));
        timer.schedule(new RemindTaskTwo(), seconds*1000);
       
    }
    
    class RemindTaskOne extends TimerTask {
        public void run(){
            System.out.println("Crop Has Grown To Stage 2!");           
        }
    }
    
    class RemindTaskTwo extends TimerTask {
        public void run(){
            System.out.println("Crop Is Ready For Harvest!");
            timer.cancel();
        }
    }
    
    public static void main(String args[]) throws InterruptedException{
        //set time 15 then add random number to stage 2?
        int randomTime = (int)(Math.random()*20)+10;
        new Task(randomTime);
        System.out.println("Crop Has Begun Growing!");
        for(int k=0; k<randomTime; k++){
            System.out.println(k);
            TimeUnit.SECONDS.sleep(1);
    }
    
    
}

}