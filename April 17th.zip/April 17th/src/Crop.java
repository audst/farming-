import static processing.core.PApplet.dist;

public class Crop extends Runner {
    
    double height;
    int age; 
    boolean harvestable; 
    int waterLevel;
    
    private static float cCenterX;
    private static float cCenterY;
    private static float cRad;
    
    
    public Crop(int cropCenterX, int cropCenterY, int cropSize){
        cCenterX = cropCenterX;
        cCenterY = cropCenterY;
        cRad = cropSize;
        height=cRad; 
    }
    
    public void drawCrop(){
        if(dist(mouseX, mouseY, cCenterX, cCenterY) < cRad){
           render();
           cRad = 0;
       }

        pushMatrix();
        beginShape();
        translate(cCenterX,cCenterY,0);
        fill(124,252,0);
        box(cRad,cRad, (float)time*2);
        endShape();
        popMatrix();
    }
    
    public void render(){
        fill(255);
        textSize(20);
        text("Your radius is: "+cRad,cCenterX-45, cCenterY-25);
    }
    
    public void step(double dtime) {
        if (height<50)
            grow(dtime);
        
    }
    
    public void grow(double dtime){
                      
           height=height+5*dtime;     
        
        
    }
    
    public void Water(){
        
        
    }
    
    public void Harvest(){
        if(harvestable==true){
            
        }
        
        
        
    }
    public String CheckStatus(){
        return("Water Level" + waterLevel + "Is Harvestable:" + harvestable + "Age" + age );
        
        
    }
    
    
    
    
}
