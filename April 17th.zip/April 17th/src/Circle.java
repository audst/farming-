
import java.awt.Color;

public class Circle {
    
    private float radius;
    private Color color;
    private int x,y;
    private boolean growing;
    private int growCount;
    private int maxGrowCount=25;
    private float growRate;
    
    public Circle(float radius, Color color, int x, int y) {
        this.radius=radius;
        this.color=color;
        this.x=x; this.y=y;
        growing=true;
        growRate=1.05f;
        growCount=(int)(Math.random()*maxGrowCount)+1;
    }
    
    public void change() {
        if (growing) {
            radius=radius*growRate;
            growCount++;
            if (growCount>=maxGrowCount) 
                growing=false;
        }
        else {
            radius=radius*(1/growRate);
            growCount--;
            if (growCount<=1)
                growing=true;
        }
    }
    
    public Color getColor() {
        return(color);
    }
    
    public float getRadius() {
        return(radius);
    }
    
    public int getX() {
        return(x);
    }
    
    public int getY() {
        return(y);
    }
}
