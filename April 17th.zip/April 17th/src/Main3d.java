import processing.core.PApplet;
import processing.core.PConstants;


public class Main3d extends PApplet {

	public void settings() {
		size(1600, 900, PConstants.P3D); // <--- P3D this tells Processing to work with 3D
	}
	
	public void draw() {
		background(140, 190, 255);
	}
	
    public static void main(String[] args) {
		
	    String[] processingArgs = { "Main" };
	    Main3d main = new Main3d();
	    PApplet.runSketch(processingArgs, main);
		
    }
}