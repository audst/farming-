import java.util.ArrayList;
import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;
import queasycam.QueasyCam;
import peasy.*;

public class Runner extends PApplet{
private float cCenterX;
private float cCenterY;
private float cRad;
    
float shapeY=400;
float shapeX=400;
float shapeSize=0;
float circleCenterX;
float circleCenterY;
float circleRadius;
float speed=10;
float rot=0;

double time=0;
double ltime=0;
double dtime=0;
double ctime=0;

PImage img;
PImage img2;
PImage img3;
QueasyCam cam;
PeasyCam camera;

boolean key_w=false;
boolean key_a=false;
boolean key_s=false;
boolean key_d=false;
boolean key_q=false;
boolean key_e=false;
boolean key_space=false;

Crop[][] crops= new Crop[10][10];

    @Override
    public void setup(){
        cam = new QueasyCam(this);
        camera = new PeasyCam(this,0,0,0,50);
        cam.sensitivity = 1;
        cam.speed = (float)0.5;
        perspective(PI/3, (float)width/height,(float) 0.2, 10000);
        camera.setLeftDragHandler(null);  
        camera.setCenterDragHandler(null);  
        camera.setRightDragHandler(null); 
        
        ltime=System.currentTimeMillis();
    }


    @Override
    public void settings(){
        fullScreen(P3D,1);
        circleCenterX = 960;
        circleCenterY = 540;
        circleRadius = 50;
        int tempC=0; 
        int tempR=0; 
        for (int c=0; c<crops.length; c++){
            for (int r=0; r<crops[0].length; r++){
                crops[c][r]= new Crop(10+tempC,10+tempR,15);
                tempR+=100;
            }
            tempR=0;
            tempC+=100;
        }
        createField(10,10);
    }

    

    public void HUD(float x){
        camera.beginHUD();
        textSize(20);
        text(x,0,20,0);
        camera.endHUD();
    }

    public void mouseObj(int circCenterX, int circCenterY, int circRad){
        this.cCenterX = circCenterX;
        this.cCenterY = circCenterY;
        this.cRad = circRad;
        if(dist(mouseX, mouseY, cCenterX, cCenterY) < cRad){
            HUD(cRad);
            fill(255, 0, 0);

        }
        else{
         fill(0, 0, 255);
        }
        beginShape();
        //rotateX(frameCount *(float)0.01);
        //rotateY(frameCount *(float)0.01);
        ellipse(cCenterX, cCenterY, cRad*2, cRad*2);
        endShape();
   }

    public void cropObj(int cropCenterX, int cropCenterY, int cropSize){
        
    }


    public void createField(int c, int r){
        int tempC=0;
        int tempR=0;

        for(int col=0; col<c; col++){
            for(int row=0; row<r; row++){
                mouseObj(10+tempC,10+tempR,15);
                tempR+=100;
            }
        tempR=0;
        tempC+=100;
        }    
    }

    /*public void collisionDetect(){

        if(dist(mouseX, mouseY, cCenterX, cCenterY) < cRad){
             fill(255, 0, 0);
            }
            else{
             fill(0, 255, 0);
            }

        if(dist(mouseX, mouseY, circleCenterX, circleCenterY) < circleRadius){
        fill(255, 0, 0);    

      }
      else{
       fill(0, 255, 0);
      }

    }*/

    @Override
    public void draw(){
        background(0);
        
        pushMatrix();
        mousePos();
        for (int c=0; c<crops.length; c++){
            for (int r=0; r<crops[0].length; r++){
                crops[c][r].drawCrop(); 
            }
        }
        popMatrix();


        ctime=System.currentTimeMillis();
        dtime=(ctime-ltime)/1000;
        time+=dtime;
        ltime=ctime;

        if (key_w)
          circleCenterY--;

        if (key_a)
          circleCenterX--;

        if (key_s)
          circleCenterY++;

        if (key_d)
          circleCenterX++;

        if (key_q){
          circleRadius++;
        }

        if (key_e)
          shapeSize--;

        //ellipse(circleCenterX, circleCenterY, circleRadius*2, circleRadius*2);
        if (mousePressed){
          cam.sensitivity=0;
          cam.speed=0;
        }
        else{
            noCursor();
            cam.sensitivity=(float) 1;
            cam.speed=(float) 0.5;
        }
    }
    
    @Override
    public void keyPressed() {
        if (key=='w')
          key_w=true;

        if (key=='a')
          key_a=true;

        if (key=='s')
          key_s=true;

        if (key=='d')
          key_d=true;

        if (key=='q')
          key_q=true;

        if (key=='e')
          key_e=true;
    }


    @Override
    public void keyReleased() {
        if (key=='w')
          key_w=false;

        if(key=='a')
          key_a=false;

        if(key=='s')
          key_s=false;

        if(key=='d')
          key_d=false;

        if(key=='q')
          key_q=false;

        if(key=='e')
          key_e=false;

    }
    
    public void mousePos(){
      noStroke();
      fill(255);
      translate(mouseX,mouseY);
      sphere(5);

    }

    public static void main(String[] args){
        String[] processingArgs = {"Boxes in Space Sketch"};
        Runner mySketch = new Runner();
        PApplet.runSketch(processingArgs, mySketch);
    }
}