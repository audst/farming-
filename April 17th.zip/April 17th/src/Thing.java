
public class Thing {
    
    int x,y,z;
    int size;
    
    public Thing() {
        x=(int)(Math.random()*400);
        y=(int)(Math.random()*400);
        z=(int)(Math.random()*400)-200;
        size=(int)(Math.random()*30)+10;
    }

//CheckGrowth();
//Harvest();
//Water();
//CheckStatus();
    



}



