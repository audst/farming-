
public class Player {


    public int money;
    public int water;
    
    
    
}
