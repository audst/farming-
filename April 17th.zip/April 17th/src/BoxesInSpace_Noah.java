import processing.core.PApplet;
import processing.core.PImage;
import queasycam.*;

public class BoxesInSpace_Noah extends PApplet{
private float cCenterX;
private float cCenterY;
private float cRad;
    
float shapeY=400;
float shapeX=400;
float shapeSize=0;
float circleCenterX;
float circleCenterY;
float circleRadius;
float speed=10;
float rot=0;

PImage img;
PImage img2;
PImage img3;
QueasyCam cam;

double time=0;
double ltime=0;
double dtime=0;
double ctime=0;

boolean key_w=false;
boolean key_a=false;
boolean key_s=false;
boolean key_d=false;
boolean key_q=false;
boolean key_e=false;

@Override
public void setup(){
    //size(400, 400, P3D);
    cam = new QueasyCam(this);
    perspective(PI/3, (float)width/height,(float) 0.2, 10000);
    ltime=System.currentTimeMillis();
}


@Override
public void settings(){
  fullScreen(P3D,1);
  //fullScreen(P3D,1);
  //img = loadImage("BACKG.jpg");
 // img2 = loadImage("saitama.png");
  //img3 = loadImage("mob_7.jpg");
  circleCenterX = 960;
  circleCenterY = 540;
  circleRadius = 50;
}


@Override
public void keyPressed() {
 if (key=='w')
   key_w=true;
   
 if (key=='a')
   key_a=true;
   
 if (key=='s')
   key_s=true;
   
 if (key=='d')
   key_d=true;

 if (key=='q')
   key_q=true;
   
 if (key=='e')
   key_e=true;
}


@Override
public void keyReleased() {
 if (key=='w')
   key_w=false;
   
 if(key=='a')
   key_a=false;
   
 if(key=='s')
   key_s=false;
   
 if(key=='d')
   key_d=false;
   
 if(key=='q')
   key_q=false;
   
 if(key=='e')
   key_e=false;
  
}

public void drawCirc(int circCenterX, int circCenterY, int circRad){
    ellipse(circCenterX, circCenterY, circRad*2, circRad*2);
}

public void useless(){
    fill(0);
    textSize(10);
    text("Your radius is: "+cRad,1820, 15);
}

    public void CircleObj(int circCenterX, int circCenterY, int circRad){
        this.cCenterX = circCenterX;
        this.cCenterY = circCenterY;
        this.cRad = circRad;
        if(dist(mouseX, mouseY, cCenterX, cCenterY) < cRad){
            useless();
            fill(255, 0, 0);
        }
        else{
         fill(0, 0, 255);
        }
        beginShape();
        ellipse(cCenterX, cCenterY, cRad*2, cRad*(float)time);
        texture(img2);
        endShape();
    }
    
    
    public void createField(int r, int c){
        //R is the 
        //C is the
        int tempC=0;
        int tempR=0;
        for(int t=0; t<r; t++){
          for(int g=0; g<c; g++){
            CircleObj(10+tempC,10+tempR,25);
            tempC+=100;
          }
          tempC=0;
          tempR+=100;
        }
        
        
    }
    
    
    
public void mousePos(){
  noStroke();
  fill(0,0,0);
  translate(mouseX,mouseY);
  sphere(5);
  
}

public void collisionDetect(){
    
    if(dist(mouseX, mouseY, cCenterX, cCenterY) < cRad){
         fill(255, 0, 0);
        }
        else{
         fill(0, 255, 0);
        }
    
    if(dist(mouseX, mouseY, circleCenterX, circleCenterY) < circleRadius){
    fill(255, 0, 0);    
    
  }
  else{
   fill(0, 255, 0);
  }
    
}

@Override
public void draw(){
  
   ctime=System.currentTimeMillis();
   dtime=(ctime-ltime)/1000;
   time+=dtime;
   ltime=ctime;
   
   
   //height=height+2*dtime;
   
   
  
   System.out.println("Seconds Passed " + time);
   background(20,255,0);
  createField(6,9);
  /*CircleObj(10,10,15);
  CircleObj(40,10,15);
  CircleObj(70,10,15);
  CircleObj(100,10,15);
  CircleObj(130,10,15);*/
  pushMatrix();
  mousePos();
  popMatrix();
  System.out.println();
  
  /*pushMatrix();
            lights();
            translate(200, 200,0);
            rotateX((float)rot);
            rotateY((float)rot);
            box(100,100,100); 
            popMatrix(); 
    */        
            
  if (key_w)
    circleCenterY--;
    
  if (key_a)
    circleCenterX--;
    
  if (key_s)
    circleCenterY++;
    
  if (key_d)
    circleCenterX++;
    
  if (key_q){
    circleRadius++;
  }
    
  if (key_e)
    shapeSize--;
  
  collisionDetect();
  
  //ellipse(circleCenterX, circleCenterY, circleRadius*2, circleRadius*2);
  if (mousePressed){
    cam.sensitivity=0;
    cam.speed=0;
  }
  else{
      noCursor();
      cam.sensitivity=(float) 0.5;
      cam.speed=3;
  }
}
        
        public static void main(String[] args){
            String[] processingArgs = {"Boxes in Space Sketch"};
            BoxesInSpace_Noah mySketch = new BoxesInSpace_Noah();
            PApplet.runSketch(processingArgs, mySketch);
    }
}