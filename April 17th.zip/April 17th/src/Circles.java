import java.awt.Color;
import processing.core.PApplet;

public class Circles extends PApplet{
    
        private Circle[] circles;
        private final  int circleCount=120;
    
        public void settings(){
                size(800, 800);
                makeCircles(circleCount);
                System.out.println("done settings");
        }
        
        public void makeCircles(int num) {
            circles=new Circle[circleCount];
            for(int k=0; k<num; k++) {
                int xpos=(int)(Math.random()*(width-40))+20;
                int ypos=(int)(Math.random()*(height-40))+20;
                int radius=(int)(Math.random()*100)+50;
                Color randomColor = new Color((int)(Math.random()*255)+1, (int)(Math.random()*255)+1,(int)(Math.random()*255)+1 );
                Circle temp = new Circle(radius, randomColor, xpos, ypos);
                circles[k]=temp;
            }
        }
	
        public void draw(){
            frameRate(25);
            background(0);
            stroke(0,0,0);
            this.strokeWeight(7.0f);
            for(int k=0; k<circleCount; k++) {
                Circle temp = circles[k];
                temp.change();
                fill(temp.getColor().getRed(), temp.getColor().getGreen(), temp.getColor().getBlue() );
                ellipse(temp.getX(), temp.getY(), temp.getRadius(), temp.getRadius() );
                
            }
            
            
        }
	
        public void keyPressed() {
            System.out.println(key);
        }
        
        public void mousePressed(){
           
        }
	
        public static void main(String[] args){
            String[] processingArgs = {"Circle Sketch"};
            Circles mySketch = new Circles();
            PApplet.runSketch(processingArgs, mySketch);
    }
}
